from model2 import *
from collections import OrderedDict
from data_edge import  *
from torch.autograd import Variable
import cv2

# test_dirs = [("/home/neverupdate/Downloads/SalGAN-master/Dataset/TEST-IMAGE", "/home/neverupdate/Downloads/SalGAN-master/Dataset/TEST-MASK")]

import numpy as np
import os
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
def load(path):
    state_dict = torch.load(path)
    state_dict_rename =  OrderedDict()
    for k, v in state_dict.items():
        name = k[7:]  # remove `module.`
        print(name)
        state_dict_rename[name] = v

    #print(state_dict_rename)
    #model.load_state_dict(state_dict_rename)

    return state_dict_rename


D_E = DSS(*extra_layer(vgg(base['dss'], 3), extra['dss'],),e_extract_layer()).cuda()
U = D_U().cuda()
#RE = refine_net().cuda()

D_E.load_state_dict(load('D_E14epoch57.pkl'))
D_E2 = DSS(*extra_layer(vgg(base['dss'], 3), extra['dss'],),e_extract_layer()).cuda()
D_E2.load_state_dict(load('D_E14epoch57.pkl'))

#RE.load_state_dict(load('./checkpoints/edges/RE2epoch10.pkl'))
#D_E.base.load_state_dict(torch.load('./weights/vgg16_feat.pth'))
U.load_state_dict(load('U14epoch57.pkl'))
p= './PRE/'
dataset = 'DUTS'

TE_sal_dirs = [

    # ("/home/lpx/Documents/saliency_dataset/ECSSD/ECSSD-Image",
    #  "/home/lpx/Documents/saliency_dataset/ECSSD/ECSSD-Mask"),
    ("/home/lpx/Documents/saliency_dataset/DUT-test/DUT-test-Image",
     "/home/lpx/Documents/saliency_dataset/DUT-test/DUT-test-Mask")


    # ("/home/lpx/Documents/saliency_dataset/SOD/SOD-Image",
    #
    #  "/home/lpx/Documents/saliency_dataset/SOD/SOD-Mask")
    #('/home/archer/Downloads/datasets/PASCALS/PASCALS-Image',
    # '/home/archer/Downloads/datasets/PASCALS/PASCALS-Mask')
    #("/home/archer/Downloads/datasets/SED1/SED1-Image",
     #"/home/archer/Downloads/datasets/SED1/SED1-Mask")
    #("/home/archer/Downloads/datasets/SED2/SED2-Image",
     #"/home/archer/Downloads/datasets/SED2/SED2-Mask")
       # ("/home/archer/Downloads/datasets/OMRON/OMRON-Image",
     #"/home/archer/Downloads/datasets/OMRON/OMRON-Mask")

        #("/home/archer/Downloads/datasets/THUR-Image",
         #"/home/archer/Downloads/datasets/THUR-Mask")
     #("/home/archer/Downloads/datasets/MSRA5000/MSRA5000-Image",

    #"/home/archer/Downloads/datasets/MSRA5000/MSRA5000-Mask")
    #("/home/archer/Downloads/datasets/HKU-IS/HKU-IS_Image",
     #"/home/archer/Downloads/datasets/HKU-IS/HKU-IS-Mask")

    ]


def process_data_dir(data_dir):
    files = os.listdir(data_dir)
    files = map(lambda x: os.path.join(data_dir, x), files)
    return sorted(files)


batch_size = 1
DATA_DICT = {}

IMG_FILES = []
GT_FILES = []

IMG_FILES_TEST = []
GT_FILES_TEST = []


TE_ed_dir = [  ("/home/lpx/Documents/saliency_dataset/SED1/SED1-Image",
     "/home/lpx/Documents/saliency_dataset/SED1/SED1-Mask")]


def DATA(sal_dirs,ed_dir,trainable):


    S_IMG_FILES = []
    S_GT_FILES = []

    E_IMG_FILES = []
    E_GT_FILES = []


    for dir_pair in sal_dirs:
        X, y = process_data_dir(dir_pair[0]), process_data_dir(dir_pair[1])
        S_IMG_FILES.extend(X)
        S_GT_FILES.extend(y)

    for dir_pair in ed_dir:
        X, y = process_data_dir(dir_pair[0]), process_data_dir(dir_pair[1])
        E_IMG_FILES.extend(X)
        E_GT_FILES.extend(y)

    S_IMGS_train, S_GT_train = S_IMG_FILES, S_GT_FILES
    E_IMGS_train, E_GT_train = E_IMG_FILES, E_GT_FILES

    folder = DataFolder(S_IMGS_train, S_GT_train, E_IMGS_train, E_GT_train, trainable)

    if trainable:
        data = DataLoader(folder, batch_size=BATCH_SIZE, num_workers=2, shuffle=trainable)
    else:
        data = DataLoader(folder, batch_size=1, num_workers=2, shuffle=trainable)


    return data


test_data =  DATA(TE_sal_dirs,TE_ed_dir,trainable=False)

sum_eval_mae = 0
sum_eval_loss = 0
num_eval = 0
mae = 0

evaluation = nn.L1Loss()

mean = (0.485,0.456,0.406)
std = (0.229,0.224,0.225)
best_eval = None

sum_train_mae = 0
sum_train_loss = 0
sum_train_gan = 0
sum_fm=0

eps = np.finfo(float).eps
##train
eval2 =0
for iter_cnt, (img,img_e,sal_l,sal_e,ed_l,s_ln,w_e,w_s_e,w_s_m,labels,e_labels,e_ln) in enumerate(test_data):
    D_E.eval()
    D_E2.eval()
    U.eval()
    label_batch = Variable(sal_l).cuda()

    print(iter_cnt)




    save_e = './PRE/edge/edge_1/'+str(e_ln)[2:-7]+'.png'
    save_e2 = './PRE/' + dataset + '/edge/' + str(e_ln)[2:-7] + '_pre2.png'

    save_e_l = './PRE/'+dataset+'/edge/'+str(e_ln)[2:-7]+'_l.png'
    save_se =['./PRE/'+dataset+'/ms3/'+str(s_ln)[2:-7]+'_3.png',
              './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_4.png',
              './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_6.png'
              ]
    save_mm = ['./PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_0.png',
               './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_1.png',
               './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_2.png'
               ]
    save_u_mm = ['./PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_0.png',
               './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_2.png',
               './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_4.png',
                 './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_6.png'
               ]
    save_u_se = ['./PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_1.png',
                 './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_3.png',
                 './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '_u_5.png'
                 ]
    save_mm2 ='./PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + '2.png'

    save_re = './PRE/' + dataset + '/ms3/' + str(s_ln)[2:-7] + 're.png'
    save_se_l = './PRE/' + dataset + '/se/' + str(s_ln)[2:-7] + '.png'

    #save_f_e = './PRE/' + dataset + '/feature/' + str(s_ln)[2:-7] + '_e.png'

    #save_f_l = './PRE/' + dataset + '/feature/' + str(s_ln)[2:-7] + '_l.png'
    img_batch = Variable(img.cuda())  # ,Variable(z_.cuda())
    img_e = Variable(img_e.cuda())


    ed_l = ed_l.cpu().numpy()
    se_l = sal_e.cpu().numpy()


    # ma = masks[3].data.cpu().numpy()

    # print(es[2].shape)
    # ee = es[2].data.cpu().numpy()
    # e_l = (np.sum(ee)-sum(sal_e)).sum()
    # print(e_l)
    #gt = label_batch.data.cpu().numpy()
    # print(np.shape(gt))
    #print(np.shape(edge))
    # cv2.imwrite(save_p,ma[0,0,:,:]*255)
    #cv2.imwrite(save_se_l, se_l[0, 0, :, :] * 255)

    f, m, e, PRE_E = D_E2(img_batch, img_e)

    U_masks, U_es,ll= U(f)
    #predic = RE(ll)
    predic = U_masks[3]
    U_mm = [U_masks[0].data.cpu().numpy(),
         U_masks[1].data.cpu().numpy(),
         U_masks[2].data.cpu().numpy(),
            U_masks[3].data.cpu().numpy()]
    U_ee = [U_es[0].data.cpu().numpy(),
         U_es[1].data.cpu().numpy(),
         U_es[2].data.cpu().numpy()]
    se= [e[0].data.cpu().numpy(),
         e[1].data.cpu().numpy(),
         e[2].data.cpu().numpy()]
         #es[3].data.cpu().numpy()]
    mm = [m[3].data.cpu().numpy(),
          m[4].data.cpu().numpy(),
          m[5].data.cpu().numpy()]
    save_p = './PRE/'+dataset+'/mask/'+str(s_ln)[2:-7]+'.png'
    re = U_masks[3].data.cpu().numpy()

    print(save_p)
    print(U_mm[3].shape)
    cv2.imwrite(save_p,255*U_mm[3].squeeze().squeeze())


    ma =predic.data.cpu().numpy()
    edge = PRE_E[3].data.cpu().numpy()

    #f_e =

    #for i in range(3):
    #    cv2.imwrite(save_se[i],se[i][0,0,:,:]*255)
    #    cv2.imwrite(save_mm[i],mm[i][0,0,:,:]*255)
    #    cv2.imwrite(save_u_se[i],U_ee[i][0,0,:,:]*255)
    #    cv2.imwrite(save_u_mm[i],U_mm[i][0,0,:,:]*255)
    #cv2.imwrite(save_u_mm[3], U_mm[3][0, 0, :, :] * 255)
    #cv2.imwrite(save_e,edge[0,0,:,:]*255)
    #cv2.imwrite(save_e2, edge2[0,0,:,:]*255)
    #cv2.imwrite(save_e_l,ed_l[0,0,:,:]*255)
    #cv2.imwrite(save_p,ma[0,0,:,:]*255)


