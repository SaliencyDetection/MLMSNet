# MLMSNet
MLMSNet Code for paper in CVPR2019, 'A Mutual Learning Method for Salient Object Detection with intertwined Multi-Supervision' 

### Results: https://pan.baidu.com/s/1jALP-XBARinFCalKj-Aplg 
### Models:  https://pan.baidu.com/s/1A6zCkQjOHpY6PNBinCX-sw

### please  refer to mlm_model and train_mlm to use mlm method
### mlm_model has updated

### train normal model: python train.py
### train mlm model: python train_mlm.py

